﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Ship))]
public class CrewAndShipEditor : Editor
{
    Ship ship;
    public string[] myChoices = new string[] { "Ship", "Crew Member"};
    private SerializedObject shipStuff;
    private SerializedProperty crew;
    private SerializedProperty guns;

    int myClassType = 0;

    void OnEnable()
    {
        ship = (Ship)target;
        shipStuff = new SerializedObject(target);
    }

    public override void OnInspectorGUI()
    {
        Selector();
        //base.OnInspectorGUI();
    }

    public void Selector()
    {
        crew = shipStuff.FindProperty("crewMembers");
        guns = shipStuff.FindProperty("shipGuns");
        EditorGUILayout.LabelField("Class Info", EditorStyles.boldLabel);
        EditorGUILayout.BeginVertical("button");
        myClassType = GUILayout.SelectionGrid(myClassType, myChoices, 2);
        if(myClassType == 0)
        {
            ship.armor = EditorGUILayout.IntSlider("Armor: ", ship.armor, 10, 100 - ship.attack - ship.agility);
            ship.attack = EditorGUILayout.IntSlider("Attack: ", ship.attack, 10, 100 - ship.armor - ship.agility);
            ship.agility = EditorGUILayout.IntSlider("Agility: ", ship.agility, 10, 100 - ship.armor - ship.attack);
            ship.hitPoints = EditorGUILayout.IntSlider("Ship Hit Points: ", ship.hitPoints, 1, 100);
            EditorGUILayout.PropertyField(guns, new GUIContent("The Ship's Guns"), true);
        }
        else
        {
            EditorGUILayout.PropertyField(crew, new GUIContent("The Ship's Crew"), true);
        }
        shipStuff.ApplyModifiedProperties();
        EditorGUILayout.EndVertical();
    }
}
